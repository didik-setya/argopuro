<?php
$month = $this->model->get_month_data();
$last_year = date('Y', strtotime('-1 year'));
$this_year = date('Y');
?>

<style>
    #table thead tr:nth-child(1) {
        background-color: #0d1273;
        color: white;
    }

    .bg-kuning {
        background-color: #ebe286;
    }
</style>

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-12">
                <h3>Evaluasi Stok Kavling Splitsing</h3>
            </div>

            <div class="col-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <table class="table table-bordered" id="table">
                            <thead>
                                <tr>
                                    <th rowspan="4">#</th>
                                    <th rowspan="4">Perumahan</th>
                                    <th rowspan="4">Blok</th>
                                    <th rowspan="4">Jml Kvl</th>

                                    <th colspan="3">L. Tanah</th>

                                    <th rowspan="4">No. Induk</th>
                                    <th rowspan="4">No. Sert</th>
                                    <th rowspan="4">Tgl. Daftar</th>
                                    <th rowspan="4">Tgl. Terbit</th>
                                    <th rowspan="4">Batas Waktu HGB</th>

                                    <th colspan="6">Belum Terbit Split</th>
                                    <th colspan="6">Terbit Stok</th>

                                    <th colspan="12">Penjualan <?= $this_year ?></th>
                                    <th rowspan="4">Ket</th>
                                </tr>

                                <tr>
                                    <th rowspan="3" class="bg-secondary">Technic</th>
                                    <th rowspan="3" class="bg-secondary">Sert</th>
                                    <th rowspan="3" class="bg-secondary">Selisih</th>

                                    <th colspan="2" class="bg-kuning">Belum Proses</th>
                                    <th colspan="2" class="bg-kuning">Proses</th>
                                    <th colspan="2" class="bg-kuning">Total</th>

                                    <th colspan="2" class="bg-kuning">s/d Tahun <?= $last_year ?></th>
                                    <th colspan="2" class="bg-kuning">Tahun <?= $this_year ?></th>
                                    <th colspan="2" class="bg-kuning">Total</th>

                                    <th colspan="6" class="bg-info">Stock</th>
                                    <th colspan="6" class="bg-info">Belum Terbit Split</th>
                                </tr>

                                <tr>
                                    <th rowspan="2" class="bg-secondary">Kav</th>
                                    <th rowspan="2" class="bg-secondary">Sert</th>
                                    <th rowspan="2" class="bg-secondary">Kav</th>
                                    <th rowspan="2" class="bg-secondary">Sert</th>
                                    <th rowspan="2" class="bg-secondary">Kav</th>
                                    <th rowspan="2" class="bg-secondary">Sert</th>

                                    <th rowspan="2" class="bg-secondary">Kav</th>
                                    <th rowspan="2" class="bg-secondary">Sert</th>
                                    <th rowspan="2" class="bg-secondary">Kav</th>
                                    <th rowspan="2" class="bg-secondary">Sert</th>
                                    <th rowspan="2" class="bg-secondary">Kav</th>
                                    <th rowspan="2" class="bg-secondary">Sert</th>

                                    <th colspan="2" class="bg-kuning">s/d Tahun <?= $last_year ?></th>
                                    <th colspan="2" class="bg-kuning">Tahun <?= $this_year ?></th>
                                    <th colspan="2" class="bg-kuning">Total</th>

                                    <th colspan="2" class="bg-kuning">Belum Proses</th>
                                    <th colspan="2" class="bg-kuning">Proses</th>
                                    <th colspan="2" class="bg-kuning">Total</th>
                                </tr>

                                <tr>
                                    <th class="bg-secondary">Kav</th>
                                    <th class="bg-secondary">Sert</th>
                                    <th class="bg-secondary">Kav</th>
                                    <th class="bg-secondary">Sert</th>
                                    <th class="bg-secondary">Kav</th>
                                    <th class="bg-secondary">Sert</th>

                                    <th class="bg-secondary">Kav</th>
                                    <th class="bg-secondary">Sert</th>
                                    <th class="bg-secondary">Kav</th>
                                    <th class="bg-secondary">Sert</th>
                                    <th class="bg-secondary">Kav</th>
                                    <th class="bg-secondary">Sert</th>

                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<script>
    $('#table thead tr th').addClass('text-center text-nowrap')
</script>