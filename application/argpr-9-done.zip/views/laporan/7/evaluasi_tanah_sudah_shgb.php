<?php
$tanah_proyek = $this->db->get('master_proyek')->result();
$f_proyek = $this->input->get('proyek');
$f_status = $this->input->get('status');

$last_year = date('Y', strtotime('-1 year'));
$this_year = date('Y');

$last_data = $this->laporan->get_data_shgb($f_proyek, $f_status, $last_year)->result();
$this_data = $this->laporan->get_data_shgb($f_proyek, $f_status, null, $this_year)->result();
?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-12">
                <h3>Evaluasi Proyek Sudah SHGB</h3>

                <div class="card">
                    <div class="card-body table-responsive">
                        <!-- <form action="<?php echo site_url('Export_excel/export_laporan_master_tanah/') ?>" method="get"> -->
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <select data-plugin-selectTwo class="form-control" id="proyek_id" name="proyek_id">
                                        <option value="">Semua Lokasi</option>
                                        <?php foreach ($tanah_proyek as $tp) : ?>
                                            <option value="<?php echo $tp->id; ?>"><?php echo $tp->nama_proyek; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <select data-plugin-selectTwo class="form-control" id="status_proyek" name="status_proyek">
                                        <option value="">Status Proyek</option>
                                        <option value="1">Luar Ijin</option>
                                        <option value="2">Dalam Ijin</option>
                                        <option value="3">Lokasi</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 text-right ">
                                <a class="btn btn-success btn-sm" onclick="filter_data()"><i class="fas fa-filter"></i> Filter Data</a>
                                <button class="btn btn-secondary btn-sm" type="submit"><i class="fa fa-print"></i> Cetak</button>
                            </div>
                        </div>
                        <!-- </form> -->

                        <table class="table table-bordered table-sm" id="table-shgb">
                            <thead>
                                <tr class="bg-dark text-light">
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">NO</th>
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">SHGB</th>
                                    <th rowspan="2" colspan="2" style="text-align: center;vertical-align: middle;">DATA TANAH</th>
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">BATAS WAKTU SHGB</th>
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">POSISI SURAT</th>
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">JML SHGB</th>
                                    <th colspan="4" style="text-align: center;vertical-align: middle;">PROSES SPLIT</th>
                                    <th colspan="2" style="text-align: center;vertical-align: middle;">PROSES GABUNG</th>
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">TERBIT PROSES</th>
                                    <th colspan="2" rowspan="2" style="text-align: center;vertical-align: middle;">SISA SETELAH TERBIT</th>
                                    <th rowspan="3" style="text-align: center;vertical-align: middle;">KETERANGAN</th>
                                </tr>
                                <tr class="bg-primary text-light">
                                    <th rowspan="2" style="text-align: center;vertical-align: middle;">JML SHGB</th>
                                    <th colspan="3" style="text-align: center;vertical-align: middle;">LUAS</th>
                                    <th rowspan="2" style="text-align: center;vertical-align: middle;">JML SHGB</th>
                                    <th rowspan="2" style="text-align: center;vertical-align: middle;">LUAS</th>
                                </tr>
                                <tr>
                                    <th style="text-align: center;vertical-align: middle;">ATAS NAMA</th>
                                    <th style="text-align: center;vertical-align: middle;"> LUAS</th>
                                    <th style="text-align: center;vertical-align: middle;">SHGB</th>
                                    <th style="text-align: center;vertical-align: middle;"> PROSES </th>
                                    <th style="text-align: center;vertical-align: middle;">TERBIT</th>
                                    <th style="text-align: center;vertical-align: middle;">JML</th>
                                    <th style="text-align: center;vertical-align: middle;">LUAS</th>
                                </tr>
                            </thead>

                            <tbody>
                                <!-- s/d last year -->
                                <tr style="background: #dedda0;">
                                    <th>A</th>
                                    <th>s/d Tahun <?= $last_year ?></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                <?php 
                                    $i=1; 
                                    $jml_luas_tanah = 0;
                                    $jml = 0;
                                    foreach($last_data as $ld){ 
                                    $date_exp = date_create($ld->masa_berlaku_shgb);    
                                ?>
                                    <tr>
                                        <td><?= $i++ ?></td>
                                        <td><?= $ld->no_terbit_shgb ?></td>
                                        <td><?= $ld->atas_nama_pengalihan ?></td>
                                        <td><?= $ld->luas_terbit ?></td>
                                        <td><?= date_format($date_exp, 'd F Y') ?></td>
                                        <td><?= $ld->atas_nama_pengalihan ?></td>
                                        <td>1</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                <?php } ?>
                                <tr style="background: #d6d6d6">
                                    <td></td>
                                    <th>Jumlah</th>
                                    <td></td>
                                    <td><?= $jml_luas_tanah ?></td>
                                    <td></td>
                                    <td></td>
                                    <td><?= $jml ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>



                                <!-- this year -->
                                <tr style="background: #dedda0;">
                                    <th>B</th>
                                    <th>Tahun <?= $this_year ?></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                <?php 
                                    $i=1; 
                                    $jml_luas_tanah = 0;
                                    $jml = 0;
                                    foreach($this_data as $td){ 
                                        $date_exp = date_create($td->masa_berlaku_shgb);    
                                        $jml_luas_tanah += $td->luas_terbit;
                                        $jml += 1;
                                ?>
                                    <tr>
                                        <td><?= $i++ ?></td>
                                        <td><?= $td->no_terbit_shgb ?></td>
                                        <td><?= $td->atas_nama_pengalihan ?></td>
                                        <td><?= $td->luas_terbit ?></td>
                                        <td><?= date_format($date_exp, 'd F Y') ?></td>
                                        <td><?= $td->atas_nama_pengalihan ?></td>
                                        <td>1</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                <?php } ?>

                                <tr style="background: #d6d6d6">
                                    <td></td>
                                    <th>Jumlah</th>
                                    <td></td>
                                    <td><?= $jml_luas_tanah ?></td>
                                    <td></td>
                                    <td></td>
                                    <td><?= $jml ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<script>
    const spinner = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

    $(document).ready(function() {
        $('#table-shgb').find('thead tr th').addClass('text-nowrap');
        $('#table-shgb').dataTable({
            "scrollX": true,
            "searching": true,
            "ordering": false,
            "autoWidth": true,
            columnDefs: [{
                "defaultContent": " ",
                "targets": "_all"
            }],
        })
    })

    function filter_data(){
        let proyek = $('#proyek_id').val()
        let status = $('#status_proyek').val()
        let url = '<?= base_url('dashboard/evaluasi_sudah_shgb/') ?>?proyek='+proyek+'&status='+status;
        window.location.href = url;
    }
</script>