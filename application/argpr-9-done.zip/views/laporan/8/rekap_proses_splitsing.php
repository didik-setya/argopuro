<?php
$list_proyek = $this->db->get('master_proyek')->result();

$last_year = date('Y', strtotime('-1 year'));
$this_year = date('Y');
$list_year = [$last_year, $this_year];

$f_proyek = $this->input->get('proyek');

if ($f_proyek == '') {
    $data_proyek = $list_proyek;
} else {
    $data_proyek = $this->db->get_where('master_proyek', ['id' => $f_proyek])->result();
}

?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-12">
                <h3>Evaluasi Rekap Land Bank</h3>
                <div class="card">
                    <div class="card-body table-responsive">


                        <form action="<?= base_url('export/proses_ijin_lokasi/') ?>" method="get">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <select name="proyek_f" id="proyek_f" class="form-control">
                                            <option value="">--semua proyek--</option>
                                            <?php foreach ($list_proyek as $l) { ?>

                                                <?php if ($l->id == $f_proyek) { ?>
                                                    <option selected value="<?= $l->id ?>"><?= $l->nama_proyek ?></option>
                                                <?php } else { ?>
                                                    <option value="<?= $l->id ?>"><?= $l->nama_proyek ?></option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3"></div>

                                <div class="col-md-6 text-right ">
                                    <a class="btn btn-sm btn-primary" href="<?= base_url('dashboard/rekap_proses_splitsing?proyek=' . $f_proyek) ?>" id="to_filter"><i class="fas fa-filter"></i> Filter Data</a>

                                    <a class="btn btn-sm btn-info" type="submit" href="<?= base_url('export/export_rekap_8?proyek=' . $f_proyek) ?>" id="to_print" target="_blank">
                                        <i class="fa fa-print"></i> Cetak
                                    </a>

                                </div>
                            </div>

                        </form>

                        <table class="table table-bordered table-sm" id="table">
                            <thead>
                                <tr>
                                    <th rowspan="2" class="bg-dark text-light text-center">#</th>
                                    <th rowspan="2" class="bg-dark text-light text-center">Lokasi</th>
                                    <th colspan="3" class="bg-dark text-light text-center">Proses Splitsing</th>
                                    <th colspan="12" class="bg-dark text-light text-center">Terbit Tahun <?= $this_year ?></th>
                                    <th rowspan="2" class="bg-dark text-light text-center">Sisa Belum Terbit</th>
                                    <th rowspan="2" class="bg-dark text-light text-center">Keterangan</th>
                                </tr>
                                <tr>
                                    <th class="text-white text-center" style="background-color:#3477eb ;">sd. <?= $last_year ?></th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Thn. <?= $this_year ?></th>
                                    <th class="text-white text-center" style="background-color:#3477eb ;">Jumlah</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Jan</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Feb</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Mar</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Apr</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Mei</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Jun</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Jul</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Ags</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Sep</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Okt</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Nov</th>
                                    <th class="text-white text-center" style="background-color: #3477eb;">Des</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                $i = 1;
                                $total_ps_lastyear = 0;
                                $total_ps_thisyear = 0;
                                $total_jml_ps = 0;
                                $total_sisa_blmtbt = 0;
                                $get_month = $this->model->get_month_data();


                                $terbit_month_total = '';
                                foreach ($get_month as $lm) {
                                    $data_terbit = $this->laporan->data_rekap_8(null, 'terbit', null, $lm['val'], null, $this_year)->row()->jumlah;
                                    if ($data_terbit > 0) {
                                        $terbit_month_total .= '<td>' . $data_terbit . '</td>';
                                    } else {
                                        $terbit_month_total .= '<td>-</td>';
                                    }
                                }

                                foreach ($data_proyek as $lp) {
                                    $ps_lastyear = $this->laporan->data_rekap_8($lp->id, 'proses', null, null, $last_year)->row()->jumlah;
                                    $ps_thisyear = $this->laporan->data_rekap_8($lp->id, 'proses', null, null, null, $this_year)->row()->jumlah;
                                    $jml_blmterbit = $this->laporan->data_rekap_8($lp->id, null, 'terbit')->row()->jumlah;
                                    $total_sisa_blmtbt += $jml_blmterbit;

                                    $list_data_by_month = '';
                                    foreach ($get_month as $gm) {
                                        $length_month = ceil(log10($gm['val'] + 1));
                                        if ($length_month == 1) {
                                            $bln = 0 . $gm['val'];
                                        } else if ($length_month == 2) {
                                            $bln = $gm['val'];
                                        }
                                        $data_terbit = $this->laporan->data_rekap_8($lp->id, 'terbit', null, $bln, null, $this_year)->row()->jumlah;

                                        if ($data_terbit > 0) {
                                            $list_data_by_month .= '<td>' . $data_terbit . '</td>';
                                        } else {
                                            $list_data_by_month .= '<td>-</td>';
                                        }
                                    }

                                    $jml_ps = $ps_lastyear + $ps_thisyear;

                                    $total_jml_ps += $jml_ps;
                                    $total_ps_lastyear += $ps_lastyear;
                                    $total_ps_thisyear += $ps_thisyear;
                                ?>
                                    <tr>
                                        <td><?= $i++ ?></td>
                                        <td><?= $lp->nama_proyek ?></td>
                                        <td><?= $ps_lastyear ?></td>
                                        <td><?= $ps_thisyear ?></td>
                                        <td><?= $jml_ps ?></td>
                                        <?= $list_data_by_month ?>
                                        <td><?= $jml_blmterbit ?></td>
                                        <td></td>
                                    </tr>
                                <?php } ?>

                            </tbody>
                            <tfoot>
                                <tr class="bg-info text-light">
                                    <td></td>
                                    <td>Total</td>
                                    <td><?= $total_ps_lastyear ?></td>
                                    <td><?= $total_ps_thisyear ?></td>
                                    <td><?= $total_jml_ps ?></td>
                                    <?= $terbit_month_total ?>
                                    <td><?= $total_sisa_blmtbt ?></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<script>
    $('#proyek_f').change(function() {
        let v = $(this).val();
        $('#to_filter').attr('href', '<?= base_url('dashboard/rekap_proses_splitsing?proyek=') ?>' + v)
        $('#to_print').attr('href', '<?= base_url('export/export_rekap_8?proyek=') ?>' + v)
    })
</script>